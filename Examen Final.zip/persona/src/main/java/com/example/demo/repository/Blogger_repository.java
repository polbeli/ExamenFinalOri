package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.demo.model.Blogger;

@Repository
public interface Blogger_repository extends JpaRepository<Blogger,Integer>	{
	
	 @Query("select x from Blogger x where x.nombreblogger like: var_parm")
	 public abstract List<Blogger> listarPorNombre(@Param("var_parm")String NombreBlogger);
}