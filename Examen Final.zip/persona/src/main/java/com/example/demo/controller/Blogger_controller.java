package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Blogger;
import com.example.demo.model.Blogs;
import com.example.demo.service.Blogger_service;
import com.example.demo.service.Blogs_service;

import jakarta.servlet.http.HttpSession;

@Controller
public class Blogger_controller {
	
	private Blogs_service blogsservice;
	private Blogger_service bloggerservice;
	
	@RequestMapping("/")
	public String verCrud() {
		return "crudBlogger";
	}

	@RequestMapping("/cargaBlogs")
	@ResponseBody
	public List<Blogs> listaBlo()
	{
		return blogsservice.listaBlogs();
	}
	@RequestMapping("/consultaCrudBlogger")
	public String consulta(String filtro, HttpSession session) {
		List<Blogger> lista = bloggerservice.listarPorNombre(filtro+"%");
		session.setAttribute("blogger", lista);
		return "crudBlogger";
	}
	
	@RequestMapping("/registraActualizaCrudBlogger")
	public String insertaActualiza(Blogger blogger, HttpSession session) {		
		try {
			Blogger obj= bloggerservice.insertaActualizaBlogger(blogger);
			if(obj == null) {
				session.setAttribute("MENSAJE","error al insertar o actualizar" );
		}else {
				session.setAttribute("MENSAJE","insertado y actualizado correctamente" );
			}
		}catch(Exception e) {
			e.printStackTrace();
			session.setAttribute("MENSAJE", "error al insertar y actualizar");
		}
		return "redirect:/salidaCrudBlogger";	
	}
	
	
	@RequestMapping("/eliminaCrudBlogger")
	public String eliminar(String id, HttpSession session) {		
		try {
			Optional<Blogger> obj = bloggerservice.buscarPorId(Integer.parseInt(id));
			if(obj.isPresent()) { 
				bloggerservice.eliminaModalidad(Integer.parseInt(id));
				session.setAttribute("MENSAJE","se elimino correctamente" );
		}else {
				session.setAttribute("MENSAJE","el id envido no existe" );
			}
		}catch(Exception e) {
			e.printStackTrace();
			session.setAttribute("MENSAJE", "error al eliminar");
		}
		return "redirect:/salidaCrudBlogger";	
	}
	
	
	@RequestMapping("/salidaCrudBlogger")
	public String salida(HttpSession  session) {
		List<Blogger> lista = bloggerservice.listarTodos();
		 session.setAttribute("blogger", lista);
		return "crudBlogger";
	}
}
