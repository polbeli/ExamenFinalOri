package com.example.demo.service.imple;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Blogs;
import com.example.demo.repository.Blogs_repository;
import com.example.demo.service.Blogs_service;

@Service
public class Blogs_service_imple implements Blogs_service{

	@Autowired
	private Blogs_repository repository;
	
	@Override
	public List<Blogs> listaBlogs() {
		return repository.findAll();
	}

}
