package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Blogger;

public interface Blogger_service {
	
	public abstract Blogger insertaActualizaBlogger(Blogger obj);
	public abstract void eliminaModalidad(int id);
	public abstract List<Blogger>listarTodos();
	public abstract List<Blogger>listarPorNombre(String filtro);
	public abstract Optional<Blogger>buscarPorId(int id);

}
