package com.example.demo.service.imple;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Blogger;
import com.example.demo.repository.Blogger_repository;
import com.example.demo.service.Blogger_service;


@Service
public class Blogger_service_imple implements Blogger_service{

	
	@Autowired
	private Blogger_repository repository;
	
	@Override
	public Blogger insertaActualizaBlogger(Blogger obj) {
		
		return repository.save(obj);
	}

	@Override
	public void eliminaModalidad(int id) {
		repository.deleteById(id);
		
	}

	@Override
	public List<Blogger> listarTodos() {
	
		return repository.findAll();
	}

	@Override
	public List<Blogger> listarPorNombre(String filtro) {
	
		return repository.listarPorNombre(filtro);
	}

	@Override
	public Optional<Blogger> buscarPorId(int id) {
		return repository.findById(id);
	}

}
